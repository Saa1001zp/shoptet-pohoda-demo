"""Deterministic synthetic input generators."""

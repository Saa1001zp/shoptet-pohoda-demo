"""Demo scenarios."""
